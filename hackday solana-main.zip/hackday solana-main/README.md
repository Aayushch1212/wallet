# Occam Wallet

A Solana Wallet Project with Flutter.

- Flutter front end for mobile
- Node.js / Express backend
- Solana CLI
- CoinGecko API