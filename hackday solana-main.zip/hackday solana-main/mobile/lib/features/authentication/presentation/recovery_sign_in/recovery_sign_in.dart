import 'package:flutter/material.dart';

class RecoverySignInScreen extends StatelessWidget {
  const RecoverySignInScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}
