#!/bin/bash
solana balance $1 --url $2