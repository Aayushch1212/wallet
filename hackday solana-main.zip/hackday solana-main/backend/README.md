## Occam Wallet - Node.js / Express

Backend for Occam Wallet

- Express API
- Firebase Admin for Firebase cloud services
- Solana CLI scripts for wallet creation and balance checking